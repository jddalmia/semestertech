<?php
header("Access-Control-Allow-Origin:*");
header("Content-Type:application/json; charset=UTF-8");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Instruction: replace 'C:/xampp/php/pear/PEAR/' path with 'current/path/of/PHPMailer

require 'C:/xampp/php/pear/PEAR/PHPMailer/src/Exception.php';
require 'C:/xampp/php/pear/PEAR/PHPMailer/src/PHPMailer.php';
require 'C:/xampp/php/pear/PEAR/PHPMailer/src/SMTP.php';

//get mail data and parse json
$json = file_get_contents('php://input');
$data = json_decode($json);

if(isset($data)){

$mail = new PHPMailer;
$mail -> isSMTP();
$mail -> SMTPAuth = true;
$mail -> SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail -> SMTPDebug = 2;
$mail -> Host = 'smtp.gmail.com';
$mail -> Post = '587';
$mail -> isHTML();

//authentication
$mail -> Username = "clientmailhandler@gmail.com";
$mail -> Password = "client123";
$mail -> SetFrom($data -> email);
$mail -> isHTML();
//mail content
$name = $data -> name;
$country = $data -> country;
$mails = $data->email;
$phone = $data->phone;
$message = $data->message;
 
$mail -> Subject = "Message from ".$data -> name;
$mail -> Body = "<b>Name</b> : ".$name."<br/>"."<b>Country</b> : ".$country."<br/>"."<b>Mail</b> : ".$mails."<br/>"."<b>Phone Nummber</b> : ".$phone."<br/>"."<b>".$message."</b>";

//reciever 
$mail -> AddAddress("hovardev@gmail.com");

class Response{
    public $success;
    public $message;
}

$res = new Response();

if($mail -> send()){

$res -> success = true;
$res -> message = "Mail Submitted Successfully";

}else {

$res -> success = false;
$res -> message = "Error in Submitting Mail";

}
echo json_encode($res);
}
?>