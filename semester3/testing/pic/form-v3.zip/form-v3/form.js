const form = document.querySelector("form");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  let formData = {};
  showStatus("");
  const elements = e.target;
  for (var i = 0; i < 5; i++) {

    let child = elements.children[i];
    if (child.value) {
      formData[child.name] = child.value;
    } else {
      showStatus(false,"Please fill complete form and try again");
      break;
    }
  }
  if(i === 5) sendMailToServer(formData);
});

function sendMailToServer(mail){
  //Instruction : replace 'http://localhost/webmail/webmail.php' with https://yourwebsitename.com/path/to/webmail.php
  const url = 'http://localhost/webmail/webmail.php';

  const xttp = new XMLHttpRequest();
  xttp.onload = function(){
    if(this.status === 200){
     //custom parsing
     
     const rawData = this.responseText;
     for(let i = 0; i < rawData.length ; i++){
       if(this.responseText[i] === '{'){
         const jsonRes = JSON.parse(rawData.substr(i , (rawData.length-1)));
         showStatus(jsonRes.success , jsonRes.message);
         break;
       }
     }
    }
  }
  
  xttp.open('POST' , url , true);
  xttp.send(JSON.stringify(mail));

}

//show status on form
function showStatus(success,status){
  const element = document.querySelector(".status");
  element.style.color = success?"green":"orangered";
  element.textContent = status;
}
