copy 
1: webmail.php file & PHPMailer folder in  your website root folder

2: open webmail.php and check instruction on line 8

3: open form.js and check instruction on line 22